import { Component, OnInit, AfterViewInit, ViewChild, Input, EventEmitter, Output } from '@angular/core';
//import { ClientSetupComponent } from '../client-setup/client-setup.component';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MockServiceService } from 'src/app/services/mock-service.service';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'lib-proposal',
  templateUrl: './proposals.component.html',
  styleUrls: ['./proposals.component.css']
})
export class ProposalsComponent implements OnInit {

  headers = ['PolicyNumber','Name', 'Product','Occupation', 'Number', 'DOB', 'action'];
    clients = [];
    searchForm:FormGroup;
    searched: boolean = false;
    isProposal:boolean = false;
  
    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort= new MatSort();
    @Input('sourceC') set sourceC(value: boolean) {
      this.isProposal = value;
    }
    @Output() returnClient = new EventEmitter<any>();
  
    dataSource=[{
      policyNumber: 'PN-123456',
      surname: 'Doe',
      otherNames: 'John',
      product: 'Life Insurance',
      occupation: 'Software Engineer',
      number: '08012345678',
      dob: new Date(1990, 5, 15)
    },
    {
      policyNumber: 'PN-654321',
      surname: 'Smith',
      otherNames: 'Jane',
      product: 'Car Insurance',
      occupation: 'Doctor',
      number: '08098765432',
      dob: new Date(1985, 10, 22)
    }];
    private dialogRef!: MatDialogRef<any>;
  
    constructor( public dialog: MatDialog, public toastr:ToastrService,
      private router: Router, private modalService: NgbModal,
      public mockService:MockServiceService, public spinner:NgxSpinnerService,) {
      this.searchForm = new FormGroup({
        policyNumber:new FormControl (""),
        surname:new FormControl (""),
        otherNames:new FormControl (""),
        dob:new FormControl (""),
        number:new FormControl (""),
        accountNumber:new FormControl (""),
        clientType:new FormControl (""),
        employmentNumber:new FormControl (""),
      })
     }
  
    ngOnInit(): void {
      
    }

    

    navigateToProposalDetails(element: any) {
      this.router.navigate(['/App/proposal-details'], { queryParams: { id: element.id } });
    }
    
    navigateToPremiumCard(element: any) {
      this.router.navigate(['/App/premium-card'], { queryParams: { id: element.id } });
    }
    
  
    // ngAfterViewInit(): void{
    //   this.dataSource.paginator = this.paginator;
    //   this.dataSource.sort = this.sort;
    // }
  
    openModal(content: any) {
      this.modalService.open(content, { centered: true });
    }
    // selectClient(element:any) {
    //   element.isProposal = true;
    //   const dialogRef = this.dialog.open(ClientSetupComponent,{
    //     width:'70%',
    //     height:'70%',
    //     data:element,   
    //   });
    //   dialogRef.afterClosed().subscribe((result) => {
    //     if (result !== undefined) {
    //       this.returnClient.emit(result);
    //     } else {
    //       this.toastr.error('Unable to retreive Client')
    //     }
    //   });
    // }
  
    // applyFilter(event: Event) {
    //   const filterValue = (event.target as HTMLInputElement).value;
    //   this.dataSource!.filter = filterValue.trim().toLowerCase();
    // }
  
    // search(){
    //   this.spinner.show();
    //   setTimeout(() => {
    //     this.mockService.getClients().subscribe((res:any)=>{
    //       this.clients = res;
    //       this.dataSource = new MatTableDataSource<any>(this.clients);
    //       this.dataSource.paginator = this.paginator;
    //       this.searched = true; 
    //       this.spinner.hide();
    //     },(error:HttpErrorResponse)=>{
    //       this.toastr.error(error.message);
    //       this.spinner.hide();
    //     })
    //   }, 1500);
      
    // }
    // create(){
    //   const dialogRef = this.dialog.open(ClientSetupComponent,{
    //     width:'70%',
    //     height:'70%',
    //     data:'',   
    //   });
    //   dialogRef.afterClosed().subscribe((result) => {
    //     if (result !== undefined) {
    //       this.returnClient.emit(result);
    //     } else {
    //       this.toastr.error('Unable to retreive Client')
    //     }
    //   });
    // }
  

}
