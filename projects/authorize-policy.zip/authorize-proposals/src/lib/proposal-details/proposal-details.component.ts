import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import * as bootstrap from 'bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'lib-proposal-details',
  templateUrl: './proposal-details.component.html',
  styleUrls: ['./proposal-details.component.css']
})
export class ProposalDetailsComponent implements OnInit {
  myForm!: FormGroup;
  constructor(private location: Location, private modalService: NgbModal, private fb: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      product: ['', Validators.required],
      effectiveDate: ['', Validators.required],
      policyNumber: ['', Validators.required],
      proposalNumber: ['', Validators.required],
      referenceNo: ['', Validators.required],
      assured: ['', Validators.required],
      lifeAssured: ['', Validators.required],
      lifeClass: ['', Validators.required],
      occupation: ['', Validators.required],
      productOption: ['', Validators.required],
      premiumMask: ['', Validators.required],
      branch: ['', Validators.required],
      agent: ['', Validators.required],
      marketer: ['', Validators.required],
      paymentMode: ['', Validators.required],
      paymentFrequency: ['', Validators.required],
      term: ['', Validators.required],
      lifeRider: ['', Validators.required],
      coinsurance: ['', Validators.required],
      retirementAge: ['', Validators.required],
      lifeCoverFactor: ['', Validators.required],
      lapseTime: ['', Validators.required],
      returnToDate: ['', Validators.required],
      returnFromDate: ['', Validators.required],
      proposalSignDate: ['', Validators.required],
      submissionDate: ['', Validators.required]
    });
  }
  openModal(content: any) {
    this.modalService.open(content, { 
      centered: true, 
      backdrop: 'static', 
      size: 'lg' 
    });
  }

  openVerifyModal(verifycontent: any) {
    this.modalService.open(verifycontent, {
      centered: true,
      backdrop: 'static',
      size: 'sm'
    })
  }
  
  
  
  goBack() {
    this.location.back();
  }
  element = {
    policyNumber: 'POL123456',
    proposalNumber: 'PROP98765',
    status: 'Active',
    maturityDate: new Date(2030, 11, 25),
    product: 'Life Insurance',
    effectiveDate: new Date(2022, 5, 15),
    assured: 'John Doe',
    lifeAssured: 'John Doe',
    jointLifeAssured: 'Jane Doe',
    occupation: 'Software Engineer',
    branch: 'New York',
    premiumAutoIncrement: 'Yes',
    paidToDate: new Date(2024, 7, 1),
    underwritingYear: 2022,
    proposalSignDate: new Date(2022, 3, 10),
    inceptionDate: new Date(2022, 4, 5),
    referenceNo: 'REF00123',
    policyClientStatus: 'Verified',
    monthlyIncome: 5000,
    acceptanceDate: new Date(2022, 6, 20),
    submissionDate: new Date(2022, 2, 25),
    commissionAmount: new Date(2022, 2, 25),
    totalPremiumPaid: '200000',
    boDebitDay:new Date(2022, 2, 25),
    boStartDate: new Date(2022, 2, 25),
    workingANB: 'New',
    bankAccount: '2136475674',
    lifeClass: 'Class A',
    productOption: 'Option 1',
    premiumMask: 'ES Default',
    agent: '',
    marketer: '',
    paymentMode: '',
    paymentFrequency: '',
    term: '',
    lifeRider: '',
    coinsurance: '',
    retirementAge: '',
    lifeCoverFactor: '',
    lapseTime: '',
    returnFromDate: '',
    returnToDate: ''
  }
   displayedColumns: string[] = ['policyNumber', 'proposalNumber', 'name', 'product', 'dob'];
  dataSource = [
    { policyNumber: 'P12345', proposalNumber: 'PR1234', name: 'John Doe', product: 'Life Insurance', dob: new Date('1985-02-15') },
    { policyNumber: 'P67890', proposalNumber: 'PR5678', name: 'Jane Smith', product: 'Health Insurance', dob: new Date('1990-08-22') },
  ];

  endorsementDisplayedColumns: string[] = ['endorsementNumber', 'endorsementDate', 'endorsementType'];
  endorsementDataSource = [
    { endorsementNumber: 'EN123', endorsementDate: new Date('2024-02-01'), endorsementType: 'Addition' },
    { endorsementNumber: 'EN456', endorsementDate: new Date('2024-02-10'), endorsementType: 'Modification' },
  ];

}
