import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-authorize-proposals',
  template: `
    <p>
      authorize-proposals works!
    </p>
  `,
  styles: [
  ]
})
export class AuthorizeProposalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
