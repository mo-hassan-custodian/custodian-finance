/*
 * Public API Surface of authorize-proposals
 */

export * from './lib/authorize-proposals.service';
export * from './lib/authorize-proposals.component';
export * from './lib/authorize-proposals.module';


